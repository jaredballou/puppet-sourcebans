﻿** Readme **

SourceBans | Global admin and ban management for the Source engine

Copyright © 2007-2014 SteamFriends, InterWave Studios and GameConnect

---------

Authors: SourceBans Development Team

Website: www.sourcebans.net

IRC: #sourcebans @ gamesurge.net

Install help: http://www.sourcebans.net/manual

Having troubles?
FAQ: http://www.sourcebans.net/faq

Prerequisites
 * Webserver
   o PHP 5.0
     * ini setting: memory_limit greater than or equal to 64M
   o MySQL 5.0
 * Source Dedicated Server
   o MetaMod: Source
   o SourceMod: greater than or equal to 1.5

